 function [F,G] = t1dietuserfun(x)
%function [F,G] = t1dietuserfun(x)
% Defines the dummy function for the (vacuous) nonlinear function
% for the problem t1diet.

F = [];  G = [];

function end_snopt

snoptmex(999);
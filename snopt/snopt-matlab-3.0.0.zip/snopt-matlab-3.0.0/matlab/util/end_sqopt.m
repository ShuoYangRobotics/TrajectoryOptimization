function end_sqopt()

sqoptmex(999);

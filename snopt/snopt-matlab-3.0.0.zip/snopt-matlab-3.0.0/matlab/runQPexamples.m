%Test Script.

format compact;
setpath;  % defines the path

fprintf('\n============================================================= ');
fprintf('\nhs76: sqopt solves quadratic problem hs76 ... ');
hs76;

fprintf('\n============================================================= ');
fprintf('\nt1diet_lp: sqopt solves linear problem t1diet_lp ... ');
t1diet_lp;
